import java.util.Scanner;

/*
Module 3 In-Class Activity: METHODS PRACTICE
Program: Eggs.java (Starter with TODOs)

Scenario:
Meadowdale Dairy Farm sells organic brown eggs.
- $3.25 per dozen
- $0.45 per loose egg (not part of a dozen)

Goal:
Prompt the user for the number of eggs and print a full explanation, e.g.:
You ordered 27 eggs. That’s 2 dozen at $3.25 per dozen and 3 loose eggs at $0.45 each for a total of $7.85.

Instructions:
Complete the TODOs. Keep your methods small and focused.
*/

public class Eggs {

    // TODO 1: Create constants for prices:
    private static final double PRICE_PER_DOZEN  = 3.25;
    private static final double PRICE_PER_LOOSE_EGG  = 0.45;

    // TODO 2: Create a method named calculateDozens(int eggs)
    public static int calculateDozens (int eggs) {
         return eggs/12;
    }

    // TODO 3: Create a method named calculateLooseEggs(int eggs)
    public static int calculateLooseEggs (int eggs){
        return eggs%12;
    }

    // TODO 4: Create a method named calculateTotalCost(int dozens, int looseEggs)
    public static double calculateToastCost (int dozens, int looseEggs){
        return (dozens*PRICE_PER_DOZEN) + (looseEggs*PRICE_PER_LOOSE_EGG);
    }

    // TODO 5: Create a method named buildExplanation(int eggs, int dozens, int looseEggs, double total)
    public static String buildExplanation(int eggs, int dozens, int looseEggs, double total){
        String totalFormatted = String.format("%.2f", total);
        return "You ordered " +eggs + " eggs. That's " + "dozen at $"
                + String.format("%.2f", PRICE_PER_DOZEN) + " per dozen and " + looseEggs
                + " loose eggs at $" + String.format("%.2f", PRICE_PER_LOOSE_EGG)
                + " each for a total of $" + totalFormatted + ".";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of eggs in the order: ");
        // TODO 6: Read the number of eggs (int). Validate: eggs >= 0.
        int eggs = input.nextInt();

        if (eggs < 0) {
            System.out.println("Error: Number of eggs cannot be negative.");
            input.close();
            return; }
        // TODO 7: Use your methods to compute:
        int dozens = calculateDozens(eggs);
        int looseEggs = calculateLooseEggs(eggs);
        double totalCost = calculateToastCost(dozens, looseEggs);
        String explanation = buildExplanation(eggs, dozens, looseEggs, totalCost);

        System.out.println(explanation);

        input.close();
    }
}
